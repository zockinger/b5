                         Regina 3.9.1
                         5 April 2015

Changes in this release (from 3.9.0)
----------------------------------
  * Fix for Bug #396, #418, #429, #432, #434, #437, #441, #443, #449, #451
  * Feature request #37
